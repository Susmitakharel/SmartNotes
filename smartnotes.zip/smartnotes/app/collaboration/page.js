'use client';
import './page.css';
import Model from 'react-modal';
import React, { useEffect, useState } from 'react';
import UsersList from '../notes/components/UsersList';
import AddUser from '../notes/components/AddUser';
import { useRouter } from 'next/navigation';
import Hdr from '../component/Hdr2';


const Home = () => {

  const [visible, setvisable] = useState(false);

  const router = useRouter();



  const [users, setUsers] = useState([]);

  const handleAddUser = (newUser) => {
    setUsers((prevUsers) => [...prevUsers, newUser]);
  };
 
  const handleDelete = id => {
    setUsers(prevUsers => prevUsers.filter(user => user.id !== id));
  };

  


  return (
    
    <div className='collabstuff'>
        <div >
            <Hdr />
        </div>
    <div className='collabpager'>

      <div className='collabfirst'> 
    
        <img src='https://htmlcolorcodes.com/assets/images/colors/gray-color-solid-background-1920x1080.png' alt='Profile Picture' width={50}/>
        <h3> First Last Name</h3>
        <h3> asdf@email.com </h3>
        <hr/>
        <div>
          <button className='collabdir' type="button" onClick={() => router.push('../dashboard')}  > Dashboard </button>
        </div>

        <div>
          <button className='collabdir' type="button" onClick={() => router.push('../notes')} > Notes </button>
        </div>

        <div>
        <button className='collabdir' type="button"  onClick={() => router.push('../collaboration')} > Members </button>
        </div>

        <div>
          <button className='collabdir' type="button" onClick={() => router.push('../settings')}> Settings </button>
        </div>
        
        
      </div>

      <div className='collabmiddlez'> 
        

        <div className='collabmiddle11'>
          <div className='collabbordss'>
            <h1 className='collabbords11'> Join Another User's Notes </h1>

          </div>  

        </div>

      
        <div className='collabmiddle33'>
          

          <form className='collabForm' id="collaborationForm">
            <label className='collabFormUsername' for="userName">
              Username:
            </label> 
            
            <input type='text' id='userName' name='userName'></input> <br></br><br></br>

            <label for="noteId">
              Note Id:
            </label> 

            <input type='text' id='userName' name='userName'></input> <br></br> <br></br>

            <button type="submit" form="collaborationForm" value="Submit">Submit</button>

          </form>
         
        </div>

      </div>

      

    </div>
    </div>
  );
}

export default Home;