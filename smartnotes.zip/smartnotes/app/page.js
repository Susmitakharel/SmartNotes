'use client';

import React, { useEffect, useState } from 'react';
import './page.css';

import Hdr from './component/Hdr'



// create and export home
const Home = () => {
  
  return (
    <div className='content'>
      <div className='HDRScreen'> 
        <Hdr />
        
        <div className='textHome'>
          <h1> Your Notes, Organized</h1>
          <h3> Easily create, organize, and share your notes </h3>
          <h3>with SmartNotes </h3>
        </div>

        <div className='imgButton'>
          <button type='button' className='imgButtonAlign'> Sign Up </button>
          <button type='button' className='imgButtonAlign'> Demo </button>
          <button type='button' className='imgButtonAlign'> About Us </button>
        </div>

        
      </div>
      


    </div>


    
  );
}
export default Home;
