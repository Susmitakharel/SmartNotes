import dynamic from 'next/dynamic';
import React, { useState } from 'react';

// Dynamically import TinyMCE's Editor, disabling SSR
const Editor = dynamic(() => import('@tinymce/tinymce-react').then((mod) => mod.Editor), { ssr: false });

const TextEditor = () => {
  const [content, setContent] = useState('');

  const handleEditorChange = (content) => {
    setContent(content);
    console.log('Content was updated:', content);
  };

  return (
    <div>
      {typeof window !== 'undefined' && (
        <Editor
          apiKey="26cpmnpeh5ed4t4fmvydyjecoasm6iq617myfv2xrwahns7f"  
          initialValue="<p>Write something here...</p>"
          init={{
            height: 500,
            menubar: false,
            plugins: [
              'advlist autolink lists link image charmap print preview anchor',
              'searchreplace visualblocks code fullscreen',
              'insertdatetime media table paste code help wordcount',
              'lists'  
            ],
            toolbar:
              'undo redo | formatselect | bold italic backcolor | ' +
              'bullist numlist | alignleft aligncenter alignright alignjustify | ' +
              'removeformat | help',
            content_css: 'default',
          }}
          onEditorChange={handleEditorChange}
        />
      )}
      
    </div>
  );
};

export default TextEditor;