'use client';
import './page.css';
import React, { useState } from 'react';
import Hdr from '../../component/Hdr2';
import { useRouter } from 'next/navigation';
import TextEditor from './component/TextEditor'; // Ensure this import is correct

const Home = () => {

  const [users, setUsers] = useState([]);
  const router = useRouter();

  const handleAddUser = (newUser) => {
    setUsers((prevUsers) => [...prevUsers, newUser]);
  };
 
  const handleDelete = id => {
    setUsers(prevUsers => prevUsers.filter(user => user.id !== id));
  };

  return (
    <div className='pagestuff'>
      <div>
        <Hdr />
      </div>
      <div className='pagepager'>
        <div className='pagefirst'> 
          <img src='https://htmlcolorcodes.com/assets/images/colors/gray-color-solid-background-1920x1080.png' alt='Profile Picture' width={50}/>
          <h3>First Last Name</h3>
          <h3>asdf@email.com</h3>
          <hr/>
          <div>
            <button className='pagedir' type="button" onClick={() => router.push('../dashboard')}  > Dashboard </button>
          </div>
          <div>
            <button className='pagedir' type="button" onClick={() => router.push('../notes')} > Notes </button>
          </div>
          <div>
            <button className='pagedir' type="button" onClick={() => router.push('../collaboration')} > Members </button>
          </div>
          <div>
            <button className='pagedir' type="button" onClick={() => router.push('../settings')} > Settings </button>
          </div>
        </div>
        <div className='pagemiddlez'> 
          <div className='pagemiddle33'>
            <TextEditor />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;