'use client';
import './page.css';
import Model from 'react-modal';
import React, { useEffect, useState } from 'react';
import UsersList from '../notes/components/UsersList';
import AddUser from '../notes/components/AddUser';
import { useRouter } from 'next/navigation';
import Hdr from '../component/Hdr2';


const Home = () => {

  const [visible, setvisable] = useState(false);

  const router = useRouter();



  const [users, setUsers] = useState([]);

  const handleAddUser = (newUser) => {
    setUsers((prevUsers) => [...prevUsers, newUser]);
  };
 
  const handleDelete = id => {
    setUsers(prevUsers => prevUsers.filter(user => user.id !== id));
  };

  


  return (
    
    <div className='settingstuff'>
        <div >
            <Hdr />
        </div>
    <div className='settingpager'>

      <div className='settingfirst'> 
    
        <img src='https://htmlcolorcodes.com/assets/images/colors/gray-color-solid-background-1920x1080.png' alt='Profile Picture' width={50}/>
        <h3> First Last Name</h3>
        <h3> asdf@email.com </h3>
        <hr/>
        <div>
          <button className='settingdir' type="button" onClick={() => router.push('../dashboard')}  > Dashboard </button>
        </div>

        <div>
          <button className='settingdir' type="button" onClick={() => router.push('../notes')} > Notes </button>
        </div>

        <div>
        <button className='settingdir' type="button"  onClick={() => router.push('../collaboration')} > Members </button>
        </div>

        <div>
          <button className='settingdir' type="button" onClick={() => router.push('../settings')}> Settings </button>
        </div>
        
        
      </div>

      <div className='settingmiddlez'> 
        

        <div className='settingmiddle11'>
          <div className='settingbordss'>
            <h1 className='settingbords11'> Settings </h1>

          </div>  

          <div className='settingmiddle33'> 
            <label>
              Name:
              <input type="text"  onChange={(e) => setName(e.target.value)} />
            </label>
            <label>
              Email:
              <input type="email" onChange={(e) => setEmail(e.target.value)} />
            </label>
            
            <button >Save</button>
          </div>

        </div>

      
       

      </div>

      

    </div>
    </div>
  );
}

export default Home;