'use client';
import './page.css';
import Model from 'react-modal';
import React, { useEffect, useState } from 'react';
import UsersList from '../notes/components/UsersList';
import AddUser from '../notes/components/AddUser';
import { useRouter } from 'next/navigation';
import Hdr from '../component/Hdr2';


const Home = () => {

  const [visible, setvisable] = useState(false);

  const router = useRouter();



  const [users, setUsers] = useState([]);

  const handleAddUser = (newUser) => {
    setUsers((prevUsers) => [...prevUsers, newUser]);
  };
 
  const handleDelete = id => {
    setUsers(prevUsers => prevUsers.filter(user => user.id !== id));
  };

  


  return (
    
    <div className='aboutstuff'>
        <div >
            <Hdr />
        </div>
    <div className='aboutpager'>

      <div className='aboutfirst'> 
    
        <img src='https://htmlcolorcodes.com/assets/images/colors/gray-color-solid-background-1920x1080.png' alt='Profile Picture' width={50}/>
        <h3> First Last Name</h3>
        <h3> asdf@email.com </h3>
        <hr/>
        <div>
          <button className='aboutdir' type="button" onClick={() => router.push('../dashboard')}  > Dashboard </button>
        </div>

        <div>
          <button className='aboutdir' type="button" onClick={() => router.push('../notes')} > Notes </button>
        </div>

        <div>
        <button className='aboutdir' type="button"  onClick={() => router.push('../collaboration')} > Members </button>
        </div>

        <div>
          <button className='aboutdir' type="button" onClick={() => router.push('../settings')}> Settings </button>
        </div>
        
        
      </div>

      <div className='aboutmiddlez'> 
        

        <div className='aboutmiddle11'>
          <div className='aboutbordss'>
            <h1 className='aboutbords11'> About Us </h1>

          </div>  

        </div>

        <div className='aboutmiddle33'>
          
          <p>Hi, we are SmartNotes and our members consist of Susmita Kharel, Sreeja Audireddy, Thomas Nguyen, Hannad Eid, Sam Xi, and Fidel Arroyo. We realized that taking notes was a common thing among students and we wanted to find a solution to the differing styles of note taking. Our solution was creating this website application where we are able to create a digital file of an document where you are able to take notes easily. We wanted to be able to create a tool that was able to be accessed anywhere on any device with internet access that contained rich formatting options and a a seamless integration. Not only can this website application can take notes, but also contains many features such as collaboration and more. The goal was to build a tool that allowed for efficient, organized, and customizable note-taking which would make it easier to keep track of ideas and tasks in one place that could also be collaborative.</p>
        </div>

      
       

      </div>

      

    </div>
    </div>
  );
}

export default Home;