'use client';
import './page.css';
import Model from 'react-modal';
import React, { useEffect, useState } from 'react';
import UsersList from '../notes/components/UsersList';
import AddUser from '../notes/components/AddUser';
import { useRouter } from 'next/navigation';
import Hdr from '../component/Hdr2';


const Home = () => {

  const [search, setSearch] = useState('');
  const [users, setUsers] = useState([]);
  const [filter, setFilter] = useState('favorite'); // Filter state: all, favorite, or category

  const router = useRouter();

  // Add a new user
  const handleAddUser = (newUser) => {
    setUsers((prevUsers) => [...prevUsers, { ...newUser, isFavorite: false }]); // Initialize new users with isFavorite = false
  };

  // Delete a user by ID
  const handleDelete = id => {
    setUsers(prevUsers => prevUsers.filter(user => user.id !== id));
  };

  // Toggle favorite status
  const handleToggleFavorite = id => {
    setUsers(prevUsers =>
      prevUsers.map(user =>
        user.id === id ? { ...user, isFavorite: !user.isFavorite } : user
      )
    );
  };

  // Handle filter change (e.g., all, favorite, category)
  const handleFilterChange = (e) => {
    setFilter(e.target.value);
  };

  return (
    
    <div className='dashstuff'>
        <div >
            <Hdr />
        </div>
    <div className='dashpager'>

      <div className='dashfirst'> 
    
        <img src='https://htmlcolorcodes.com/assets/images/colors/gray-color-solid-background-1920x1080.png' alt='Profile Picture' width={50}/>
        <h3> First Last Name</h3>
        <h3> asdf@email.com </h3>
        <hr/>
        <div>
          <button className='dashdir' type="button" onClick={() => router.push('../dashboard')}  > Dashboard </button>
        </div>

        <div>
          <button className='dashdir' type="button" onClick={() => router.push('../notes')} > Notes </button>
        </div>

        <div>
        <button className='dashdir' type="button" onClick={() => router.push('../collaboration')} > Members </button>
        </div>

        <div>
          <button className='dashdir' type="button" onClick={() => router.push('../settings')} > Settings </button>
        </div>
        
        
      </div>

      <div className='dashmiddlez'> 
        

        <div className='dashmiddle11'>
          <div className='dashbordss'>
            <h1 className='dashbords11'> Favorited Notes </h1>
      
          </div>

        </div>

      
        <div className='dashmiddle33'>
          
          <UsersList
                search={search}
                users={users}
                onDelete={handleDelete}
                onToggleFavorite={handleToggleFavorite}  // Pass toggleFavorite handler
                filter={filter}
          />
        </div>

      </div>

      

    </div>
    </div>
  );
}

export default Home;