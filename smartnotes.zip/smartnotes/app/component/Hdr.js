import React from 'react';
import './Hdr.css';
import { useRouter } from 'next/navigation';



const Hdr = () => {
    const router = useRouter();
    return (
        <nav>
            
            <div className='leftHdr'> Logo </div>
            <div className='middleHdr'>
                <div className='whiteButtonHomepage'>
                    <button type='button'  onClick={() => router.push('../')}> Homepage </button>
                </div>
                <div className='green'>
                    <button type='button' > Demo </button>
                </div>
                <div className='green'>
                    <button type='button' onClick={() => router.push('../about')}> About Us </button>
                </div>
                

            </div>

            <div className='rightHdr'>
                <button type='button'> Signup </button>
            </div>

        </nav>
    )
}
  
  export default Hdr;