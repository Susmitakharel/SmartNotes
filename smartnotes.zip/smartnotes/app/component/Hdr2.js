import React, { useState } from 'react';
import './Hdr2.css';
import { useRouter } from 'next/navigation';


const Hdr = () => {

    const [isDropdownOpen, setIsDropdownOpen] = useState(false);

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };
    
    const router = useRouter();

    return (
        <nav>
            
            <div className='leftHdr2'> Logo </div>
            <div className='middleHdr2'>
                <div>
                    <button type='button' onClick={() => router.push('../')}> Home </button>
                </div>
                <div>
                    <button type='button' onClick={() => router.push('../dashboard')}> Dashboard </button>
                </div>
                <div>
                    <button type='button' onClick={() => router.push('../notes')}> Notes </button>
                </div>
                <div>
                    <button type='button' onClick={() => router.push('../collaboration')}> Collaboration </button>
                </div>
                <div>
                    <button type='button' onClick={() => router.push('../about')}> About </button>
                </div>
                
                

            </div>

            <div className='rightHdr2'>
               
                <div className="profileMenu">
                    <img src='../img/pp.jpg' alt='PP' className="profile-picture" onClick={toggleDropdown} width={50} height={50}/>
                    {isDropdownOpen && (
                        <ul className="dropdown-menu">
                        <li onClick={() => router.push('../profile')}> <h3> Profile </h3></li>
                        <li className='h3HDR'> <h3> Settings </h3></li>
                        <li className='h3HDR'> <h3> Logout </h3></li>
                        </ul>
                    )}
                </div>
                
            </div>

            

        </nav>
    )
}
  
  export default Hdr;