'use client';
import './page.css';
import Model from 'react-modal';
import React, { useEffect, useState } from 'react';
import UsersList from './components/UsersList';
import AddUser from './components/AddUser';
import { useRouter } from 'next/navigation';
import Hdr from '../component/Hdr2';

const Home = () => {

  const [visible, setVisible] = useState(false);
  const [search, setSearch] = useState('');
  const [users, setUsers] = useState([]);
  const [filter, setFilter] = useState('all'); // Filter state: all, favorite, or category

    const router = useRouter();

  // Add a new user
  const handleAddUser = (newUser) => {
    setUsers((prevUsers) => [...prevUsers, { ...newUser, isFavorite: false }]); // Initialize new users with isFavorite = false
  };

  // Delete a user by ID
  const handleDelete = id => {
    setUsers(prevUsers => prevUsers.filter(user => user.id !== id));
  };

  // Toggle favorite status
  const handleToggleFavorite = id => {
    setUsers(prevUsers =>
      prevUsers.map(user =>
        user.id === id ? { ...user, isFavorite: !user.isFavorite } : user
      )
    );
  };

  // Handle filter change (e.g., all, favorite, category)
  const handleFilterChange = (e) => {
    setFilter(e.target.value);
  };

  return (
    <div className='stuff'>
        <div>
            <Hdr />
        </div>
        <div className='pager'>
          <div className='first'>
            <img src='https://htmlcolorcodes.com/assets/images/colors/gray-color-solid-background-1920x1080.png' alt='Profile Picture' width={50}/>
            <h3>First Last Name</h3>
            <h3>asdf@email.com</h3>
            <hr/>
            <div>
              <button className='dir' type="button" onClick={() => router.push('../dashboard')}  > Dashboard </button>
            </div>
            <div>
              <button className='dir' type="button" onClick={() => router.push('../notes')} > Notes </button>
            </div>
            <div>
              <button className='dir' type="button" onClick={() => router.push('../collaboration')} > Members </button>
            </div>
            <div>
              <button className='dir' type="button" onClick={() => router.push('../settings')} > Settings </button>
            </div>
          </div>

          <div className='middlez'> 
            <div className='middle11'>
              <div className='bordss'>
                <h1 className='bords11'>All Notes</h1>
                <div>

                <input
                  type="text"
                  placeholder="Search users..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className='search-bar'
              />

                  {/* Filter Dropdown */}
                  <select onChange={handleFilterChange} className='filter-dropdown'>
                    <option value="all">All</option>
                    <option value="favorite">Favorites</option>
                    <option value="categoryA">Category A</option>
                    <option value="categoryB">Category B</option>
                  </select>
                </div>
                
                <button className='bords22' onClick={() => setVisible(true)}> New Note Page </button>
              </div>

              

              

              <Model className='formz' isOpen={visible} onRequestClose={() => setVisible(false)} style={{
                overlay: {
                  backgroundColor: 'rgba(0, 0, 0, 0.75)'  // Proper background style for overlay
                }, 
                content: {
                  width: '500px',
                  height: '500px',
                  margin: 'auto',
                  borderRadius: '10px',
                  padding: '20px',
                }
              }}>
                <div className='lexz'>
                  <button className='lex2z' onClick={() => setVisible(false)}> X </button>
                </div>
                <AddUser onAddUser={handleAddUser} />
              </Model>
            </div>

            <div className='middle33'>

              {/* Pass the filter, search term, and other necessary props */}
              <UsersList
                search={search}
                users={users}
                onDelete={handleDelete}
                onToggleFavorite={handleToggleFavorite}  // Pass toggleFavorite handler
                filter={filter}
              />
            </div>
          </div>
        </div>
    </div>
  );
};

export default Home;