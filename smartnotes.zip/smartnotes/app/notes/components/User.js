import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import './User.css';

const User = (props) => {
    const router = useRouter();
    const [isFavorite, setIsFavorite] = useState(props.isFavorite || false); // Initialize with prop

    const handleDelete = () => {
        props.onDelete(props.id);
    };

    const toggleFavorite = () => {
        setIsFavorite(!isFavorite); // Toggle favorite status
        props.onToggleFavorite(props.id); // Notify parent of the change
    };

    return (
        <div className="list11" >
            
            
        
                <h1 className='old1' onClick={() => router.push('../pages/' + props.id)}> {props.notename} </h1>
                
                
        

            
            <div onClick={() => router.push('../pages/' + props.id)}>
                <h3 className='old11'> {props.category} </h3>
                <h3 className='old11'> {props.uszer} </h3>
                <h3 className='old11'> {props.date} </h3>
                <hr className='bor1' />
            </div>
            

            {/* Favorite Button */}
            

                
                <button className='favorite-button' onClick={toggleFavorite}>
                    {isFavorite ? 'Unfavorite' : 'Favorite'}
                    
                    
                </button>
                
            
            
            <div className='exitX' onClick={handleDelete}>
                <button >X</button>  
            </div>
            
        </div>
    );
};

export default User;

