import React from 'react';
import User from './User';

const UsersList = ({ users, onDelete, search, filter }) => {

    // Filtering users based on the search and filter criteria
    const filteredUsers = users.filter((user) => {
        const matchesSearch = search.toLowerCase() === '' || user.notename.toLowerCase().includes(search);
        const matchesFilter = (filter === 'all') ||
                              (filter === 'favorite' && user.isFavorite) ||
                              (filter === user.category); // Matches selected category

        return matchesSearch && matchesFilter;
    });

    return (
        <ul className='realz'>
            {filteredUsers.map((user) => (
                <User
                    key={user.id}
                    id={user.id}
                    notename={user.notename}
                    category={user.category}
                    uszer={user.uszer}
                    date={user.date}
                    isFavorite={user.isFavorite} // Pass favorite status
                    onDelete={onDelete}
                />
            ))}
        </ul>
    );
};

export default UsersList;