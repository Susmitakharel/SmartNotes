'use client';
import React, { useState } from 'react';

import Card from './Card';
import Button from './Button';
import './AddUser.css';

const AddUser = ( {onAddUser } ) => {

  const [notename, setnotename] = useState('');
  const [topic, settopic] = useState('');
  const [uszer, setuszer] = useState('');
  const [date, setdate] = useState('');

 

  const handleSubmit = (event) => {
    event.preventDefault();

    if (notename == '' || topic == '' || uszer == '' || date == '') {
      return;
    }

    const newUser = {
      id: Math.random().toString(),
      notename: notename,
      topic: parseInt(topic),
      uszer: uszer,
      date: date
    };

    onAddUser(newUser);
    console.log(newUser);
    setnotename('');
    settopic('');
    setuszer('');
    setdate('');

  }

  return (
    <Card className="input">
      
      <form onSubmit={handleSubmit}>
        <label>Note Name: </label>
        <input
          id="notename"
          type="text"
          value={notename}
          onChange={(e) => setnotename(e.target.value)}
        />
        <label>Topic: </label>
        <input
          id="topic"
          type="text"
          value={topic}
          onChange={(e) => settopic(e.target.value)}
        />
        <label>User In Charge:</label>
         <input
          id="uszer"
          type="text"
          value={uszer}
          onChange={(e) => setuszer(e.target.value)}
        />
        <label>date</label>
         <input
          id="date"
          type="date"
          value={date}
          onChange={(e) => setdate(e.target.value)}
        />
        <div className="adding">
          <Button  type="submit" >Add Task</Button>
        </div>
      </form>
    </Card>
  );
};

export default AddUser;
